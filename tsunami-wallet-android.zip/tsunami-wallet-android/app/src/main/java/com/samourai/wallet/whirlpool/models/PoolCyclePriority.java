package com.samourai.wallet.whirlpool.models;

public enum  PoolCyclePriority{
    HIGH,
    NORMAL,
    LOW
}
